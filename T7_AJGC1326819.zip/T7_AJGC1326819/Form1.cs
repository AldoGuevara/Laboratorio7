﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace T7_AJGC1326819
{
    public partial class T7 : Form
    {
        public T7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(NumeroTextBox.Text, out int n) && n > 0)
            {
                // Serie A: (1 / 1) + (1 / 2) + (1 / 3) + ... + (1 / N)
                double serieA = 0;
                for (int i = 1; i <= n; i++)
                {
                    serieA += 1.0 / i;
                }
                SerieALabel.Text = "Serie A: " + serieA;

                // Serie B: (1 / 2^1) + (1 / 2^2) + (1 / 2^3) + ... + (1 / 2^N)
                double serieB = 0;
                for (int i = 1; i <= n; i++)
                {
                    serieB += 1.0 / Math.Pow(2, i);
                }
                SerieBLabel.Text = "Serie B: " + serieB;
            }
            else
            {
                MessageBox.Show("Ingrese un número entero mayor a 0 en N.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
