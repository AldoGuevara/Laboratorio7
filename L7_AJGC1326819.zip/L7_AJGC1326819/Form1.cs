﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace L7_AJGC1326819
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            int n;

            try
            {
                n = int.Parse(txtNumero.Text);

                if (n <= 0)
                {
                    MessageBox.Show("El número debe ser mayor que 0.", "Error");
                    return;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, ingrese un número entero válido.", "Error");
                return;
            }

            // Calcular y mostrar la sucesión de Fibonacci
            int a = 0;
            int b = 1;
            int i = 0;
            string resultado = "Sucesión de Fibonacci hasta el término " + n + ":\n";

            while (i < n)
            {
                resultado += a + " ";
                int temp = a;
                a = b;
                b = temp + b;
                i++;
            }

            MessageBox.Show(resultado, "Resultado");
        
    }
    }
}
